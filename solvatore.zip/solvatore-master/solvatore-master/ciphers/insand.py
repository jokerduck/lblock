from cipher_description import CipherDescription

# Cipher Definition
def generate_sand_version(n, rounds):
    sand = CipherDescription(2*n)
    for i in range(n):
        left_side="s{}".format(i)
        templeft="t{}".format(i+96)
        sand.apply_mov(left_side,templeft)
        
    for i in range(n // 4):
        input_01 = "s{}".format(i*4+2)
        input_02 = "s{}".format(i*4+3)
        input_11 = "s{}".format(i*4+1)
        input_12 = "s{}".format(i*4+3)
        
        product01 =  "t{}".format(i*4+32)
        product11 =  "t{}".format(i*4+80)
        
        sand.apply_and(input_01, input_02, product01)
        sand.apply_and(input_11, input_12, product11)
        
        input_03 = "s{}".format(i*4)
        input_13 = "s{}".format(i*4+2)
        
        xor_01 = "t{}".format(i*4)
        xor_11 = "t{}".format(i*4+50)
        
        sand.apply_xor(product01, input_03, xor_01)
        sand.apply_xor(product11, input_13, xor_11)
        

        input_05 = "s{}".format(i*4+1)
        input_15 = "s{}".format(i*4)
        
        product02 =  "t{}".format(i*4+40)
        product12 =  "t{}".format(i*4+88)
        sand.apply_and(xor_01, input_05, product02)
        sand.apply_and(xor_11, input_15, product12)
        
        input_06 = "s{}".format(i*4+3)
        input_16 = "s{}".format(i*4+1)
        
        xor_02 = "t{}".format(i*4+3)
        xor_12 = "t{}".format(i*4+49)
        
        sand.apply_xor(product02, input_06, xor_02)
        sand.apply_xor(product12, input_16, xor_12)

        const1="s{}".format(i*4+1)
        const2="s{}".format(i*4+2)

        tempconst1="t{}".format(i*4+1)
        tempconst2="t{}".format(i*4+2)

        sand.apply_mov(const1,tempconst1)
        sand.apply_mov(const2,tempconst2)

        const3="s{}".format(i*4+3)
        const4="s{}".format(i*4+3)

        tempconst3="t{}".format(i*4+51)
        tempconst4="t{}".format(i*4+48)
        
        sand.apply_mov(const3,tempconst3)
        sand.apply_mov(const4,tempconst4)
    
    for i in range(32):
        bef_p0="t{}".format(i)
        bef_p1="t{}".format((i+52)%80+48)
        bef_p="s{}".format(i)
        sand.apply_xor(bef_p0,bef_p1,bef_p)

    shuffle1=[7, 4, 1, 6, 3, 0, 5, 2]
    sand.shufflewords(shuffle1,4,0)
    
    for i in range(n):
        right_side="s{}".format(i+32)
        left_side="s{}".format(i)
        sand.apply_xor(left_side,right_side,left_side)

    for i in range(n):
        right_side="s{}".format(i+32)
        templeft="t{}".format(i+96)
        sand.apply_mov(templeft,right_side)
        
    return sand

sand64_128=generate_sand_version(32,12)
